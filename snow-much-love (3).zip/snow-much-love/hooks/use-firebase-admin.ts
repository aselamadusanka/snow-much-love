"use client";
import { useEffect, useState } from "react";
import { getAuth, GoogleAuthProvider, onAuthStateChanged, signInWithPopup, signOut, type User } from "firebase/auth";
import { firebaseApp } from "@/lib/firebase-client";

export function useFirebaseAdmin() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => onAuthStateChanged(getAuth(firebaseApp()), value => { setUser(value); setReady(true); }, () => setReady(true)), []);
  return {
    user, ready,
    signIn: () => {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      return signInWithPopup(getAuth(firebaseApp()), provider);
    },
    signOut: () => signOut(getAuth(firebaseApp())),
  };
}
