"use client";
import { useEffect, useRef, useState } from "react";

/** An original, softly voiced ambient composition; no remote audio download. */
export function useCalmMusic(volume: number) {
  const [status, setStatus] = useState<"ready" | "playing" | "muted" | "unavailable">("ready");
  const control = useRef<() => void>(() => {});
  const level = useRef(volume); level.current = volume;
  const master = useRef<GainNode | null>(null);
  const audio = useRef<AudioContext | null>(null);
  useEffect(() => {
    let context: AudioContext | undefined;
    let output: GainNode;
    let timer: ReturnType<typeof setInterval> | undefined;
    let enabled = true, activated = false, disposed = false, next = 0, step = 0;
    const beat = 60 / 66;
    const melody = [72, 67, 64, 67, 76, 72, 67, 64, 72, 69, 64, 69, 76, 72, 69, 64, 69, 65, 60, 65, 72, 69, 65, 60, 71, 67, 62, 67, 74, 71, 67, 62];
    const chords = [[48, 55, 64], [45, 52, 60], [41, 48, 57], [43, 50, 59]];
    const tone = (midi: number, at: number, duration: number, pad = false) => {
      if (!context) return;
      const oscillator = context.createOscillator(), envelope = context.createGain();
      oscillator.type = "sine"; oscillator.frequency.value = 440 * 2 ** ((midi - 69) / 12);
      envelope.gain.setValueAtTime(0.0001, at);
      envelope.gain.linearRampToValueAtTime(pad ? 0.075 : 0.28, at + (pad ? 1.7 : 0.045));
      envelope.gain.exponentialRampToValueAtTime(0.0001, at + duration);
      oscillator.connect(envelope); envelope.connect(output);
      oscillator.start(at); oscillator.stop(at + duration + 0.05);
      oscillator.onended = () => { oscillator.disconnect(); envelope.disconnect(); };
    };
    const schedule = () => {
      if (!context || context.state !== "running" || !enabled || document.hidden) return;
      if (next < context.currentTime) next = context.currentTime + 0.08;
      while (next < context.currentTime + 0.4) {
        tone(melody[step % melody.length], next, 3.8);
        if (step % 8 === 0) chords[Math.floor(step / 8) % 4].forEach(midi => tone(midi, next, beat * 9, true));
        step++; next += beat;
      }
    };
    const start = async () => {
      try {
        if (!context) {
          const Audio = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
          if (!Audio) { setStatus("unavailable"); return; }
          context = new Audio(); audio.current = context;
          output = context.createGain(); master.current = output; output.gain.value = level.current;
          const filter = context.createBiquadFilter(); filter.type = "lowpass"; filter.frequency.value = 1800;
          const delay = context.createDelay(2); delay.delayTime.value = beat / 2;
          const feedback = context.createGain(); feedback.gain.value = 0.23;
          const wet = context.createGain(); wet.gain.value = 0.17;
          output.connect(filter); filter.connect(context.destination);
          filter.connect(delay); delay.connect(feedback); feedback.connect(delay); delay.connect(wet); wet.connect(context.destination);
          timer = setInterval(schedule, 120);
        }
        await context.resume();
        if (disposed) return;
        if (!enabled || document.hidden) { await context.suspend(); return; }
        activated = true; setStatus("playing"); schedule();
      } catch { if (!disposed) setStatus("ready"); }
    };
    const gesture = (event: Event) => {
      if (!enabled || activated || (event.target as HTMLElement | null)?.closest?.("[data-music-toggle]")) return;
      void start();
    };
    control.current = () => {
      if (!activated) { enabled = true; void start(); return; }
      enabled = !enabled;
      if (enabled) void start(); else { setStatus("muted"); void context?.suspend(); }
    };
    const visible = () => { if (document.hidden) void context?.suspend(); else if (activated && enabled) void start(); };
    document.addEventListener("pointerdown", gesture, { passive: true }); document.addEventListener("keydown", gesture); document.addEventListener("visibilitychange", visible);
    return () => {
      disposed = true; clearInterval(timer); control.current = () => {};
      document.removeEventListener("pointerdown", gesture); document.removeEventListener("keydown", gesture); document.removeEventListener("visibilitychange", visible);
      void context?.close(); audio.current = null; master.current = null;
    };
  }, []);
  useEffect(() => { if (master.current && audio.current) master.current.gain.setTargetAtTime(volume, audio.current.currentTime, 0.3); }, [volume]);
  return { status, toggle: () => control.current() };
}
