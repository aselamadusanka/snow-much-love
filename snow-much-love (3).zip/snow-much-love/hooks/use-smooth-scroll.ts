"use client";
import { useCallback, useEffect, useRef } from "react";

export function useSmoothScroll() {
  const frame = useRef(0);
  const finish = useRef<((complete: boolean) => void) | null>(null);
  const cancel = useCallback(() => {
    cancelAnimationFrame(frame.current); frame.current = 0;
    finish.current?.(false); finish.current = null;
  }, []);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (["ArrowDown", "ArrowUp", "PageDown", "PageUp", "Home", "End", " "].includes(event.key) && !(event.target as HTMLElement).closest("input, textarea, select")) cancel();
    };
    window.addEventListener("wheel", cancel, { passive: true });
    window.addEventListener("touchstart", cancel, { passive: true });
    window.addEventListener("keydown", key);
    return () => { cancel(); window.removeEventListener("wheel", cancel); window.removeEventListener("touchstart", cancel); window.removeEventListener("keydown", key); };
  }, [cancel]);
  return useCallback((id: string, focus = false): Promise<boolean> => {
    cancel();
    const element = document.getElementById(id);
    if (!element) return Promise.resolve(false);
    const from = window.scrollY;
    const to = Math.max(0, Math.min(element.getBoundingClientRect().top + from, document.documentElement.scrollHeight - window.innerHeight));
    const distance = to - from;
    const duration = Math.min(1900, Math.max(850, 850 + Math.abs(distance) * 0.22));
    return new Promise(resolve => {
      finish.current = resolve;
      let start: number | undefined;
      const tick = (now: number) => {
        start ??= now;
        const progress = Math.min(1, (now - start) / duration);
        const ease = progress < 0.5 ? 4 * progress ** 3 : 1 - (-2 * progress + 2) ** 3 / 2;
        window.scrollTo({ top: from + distance * ease, behavior: "instant" });
        if (progress < 1) frame.current = requestAnimationFrame(tick);
        else {
          frame.current = 0; finish.current = null;
          if (focus) { const heading = element.querySelector<HTMLElement>("h1, h2"); heading?.setAttribute("tabindex", "-1"); heading?.focus({ preventScroll: true }); }
          resolve(true);
        }
      };
      frame.current = requestAnimationFrame(tick);
    });
  }, [cancel]);
}
