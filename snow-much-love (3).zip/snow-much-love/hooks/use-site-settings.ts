"use client";
import { useEffect, useState } from "react";
import { DEFAULT_SETTINGS, snapshotSchema, type SiteSettings } from "@/lib/site-settings";

/** Shared server settings, refreshed without losing the visitor's date selections. */
export function useSiteSettings(): SiteSettings {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  useEffect(() => {
    let stopped = false;
    let revision = "";
    let timer: ReturnType<typeof setTimeout>;
    let active: AbortController | undefined;
    let cloudHasSettings = false;
    let unsubscribe: (() => void) | undefined;
    let cloudTimer: ReturnType<typeof setTimeout>;
    let cloudListening = false;
    let connectCloud: (() => void) | undefined;
    const refresh = async () => {
      clearTimeout(timer);
      if (stopped || cloudHasSettings || document.hidden || active) return;
      const controller = active = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      try {
        const response = await fetch("/api/site-settings", { cache: "no-store", signal: controller.signal });
        if (!response.ok) return;
        const valid = snapshotSchema.safeParse(await response.json());
        if (!stopped && !cloudHasSettings && valid.success && valid.data.revision !== revision) { revision = valid.data.revision; setSettings(valid.data.settings); }
      } catch { /* Keep the last good settings during a temporary connection loss. */ }
      finally { clearTimeout(timeout); active = undefined; if (!stopped && !cloudHasSettings) timer = setTimeout(refresh, 1500); }
    };
    const visible = () => { if (!document.hidden) { void refresh(); connectCloud?.(); } };
    document.addEventListener("visibilitychange", visible);
    window.addEventListener("focus", visible);
    void refresh();
    void import("@/lib/firebase-settings").then(({ subscribeFirebaseSettings }) => {
      if (stopped) return;
      connectCloud = () => {
        if (stopped || document.hidden || cloudListening) return;
        clearTimeout(cloudTimer); unsubscribe?.(); cloudListening = true;
        unsubscribe = subscribeFirebaseSettings(snapshot => {
          if (stopped || !snapshot) return;
          cloudHasSettings = true; clearTimeout(timer); active?.abort();
          if (snapshot.revision !== revision) { revision = snapshot.revision; setSettings(snapshot.settings); }
        }, () => {
          // A rules/setup error terminates a Firestore listener. Retry so already
          // open invitations can connect after the owner completes setup.
          cloudListening = false;
          if (!stopped) cloudTimer = setTimeout(() => connectCloud?.(), 15000);
        });
      };
      connectCloud();
    }).catch(() => { /* Existing shared settings remain available during setup. */ });
    return () => { stopped = true; clearTimeout(timer); clearTimeout(cloudTimer); active?.abort(); unsubscribe?.(); document.removeEventListener("visibilitychange", visible); window.removeEventListener("focus", visible); };
  }, []);
  return settings;
}
