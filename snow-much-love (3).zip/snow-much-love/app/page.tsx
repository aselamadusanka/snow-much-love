"use client";

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, Check, Download, Heart, RotateCcw, Snowflake, Sparkles, Volume2, VolumeX } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Calendar } from "@/components/ui/calendar";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { ScrollVideoBackground } from "@/components/scroll-video-background";
import { EscapingNoButton } from "@/components/escaping-no-button";
import { LoopingStitch } from "@/components/looping-stitch";
import { Input } from "@/components/ui/input";
import { useSiteSettings } from "@/hooks/use-site-settings";
import { useSmoothScroll } from "@/hooks/use-smooth-scroll";
import { useCalmMusic } from "@/hooks/use-calm-music";
import { formatAmount, formatTime, isFutureDateTime, themeVariables, type Choice } from "@/lib/site-settings";

const STITCH_IMAGE = "/images/stitch-sandunika.jpg";
const HER_NAME = "Sandunika";
const VIBES: Choice[] = [{ id: "sunset", name: "Sunset date", emoji: "🌅", color: "peach" }, { id: "movie", name: "Movie night", emoji: "🎬", color: "lavender" }, { id: "drive", name: "Night drive", emoji: "🌙", color: "blue" }, { id: "beach", name: "Beach date", emoji: "🌊", color: "blue" }, { id: "adventure", name: "Adventure", emoji: "🎡", color: "pink" }, { id: "cozy", name: "Cozy date", emoji: "🧸", color: "yellow" }];
const TIMES = ["17:00", "18:00", "19:00", "20:00", "21:00"];
const dateText = (date?: Date) => date ? date.toLocaleDateString("en-US", { weekday: "short", month: "long", day: "numeric", year: "numeric" }) : "Your special day";
const dayKey = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const todayDate = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };

function SnowParticles() {
  return <div className="snowfall" aria-hidden="true">{Array.from({ length: 25 }, (_, i) => <span key={i} className={i % 8 === 0 ? "heart-particle" : "snow-particle"} style={{ "--x": `${(i * 47 + 8) % 100}%`, "--delay": `${-(i * 1.7)}s`, "--duration": `${12 + i % 9}s`, "--size": `${3 + i % 5}px`, "--drift": `${(i % 2 ? 1 : -1) * (20 + i * 3)}px` } as CSSProperties}>{i % 8 === 0 ? "♡" : ""}</span>)}</div>;
}

function Confetti({ burst }: { burst: number }) {
  return <div key={burst} className="confetti" aria-hidden="true">{burst > 0 && Array.from({ length: 65 }, (_, i) => <i key={i} style={{ "--cx": `${(i * 37) % 100}vw`, "--cy": `${((i * 29) % 50) - 40}vh`, "--cr": `${i * 49}deg`, "--cd": `${(i % 10) * .055}s`, "--color": ["#77c6ff", "#ffadc9", "#ffffff", "#c5bcff"][i % 4] } as CSSProperties}>{i % 4 === 0 ? "♥" : i % 4 === 1 ? "✦" : ""}</i>)}</div>;
}

function ChoiceCards({ items, value, onChange, label }: { items: Choice[]; value: string; onChange: (v: string) => void; label: string }) {
  return <RadioGroup value={value} onValueChange={onChange} aria-label={label} className="choice-grid">{items.map(item => <label className={`choice-card ${item.color} ${value === item.id ? "selected" : ""}`} key={item.id}>
    <RadioGroupItem value={item.id} className="choice-radio" aria-label={item.name} />
    <span className="choice-emoji" aria-hidden="true">{item.emoji}</span><span className="choice-name">{item.name}</span>
    <span className="choice-check" aria-hidden="true">{value === item.id ? <Heart size={15} fill="currentColor" /> : "+"}</span>
  </label>)}</RadioGroup>;
}

function SectionIntro({ number, title, subtitle }: { number: string; title: React.ReactNode; subtitle: string }) {
  return <div className="section-intro"><span className="eyebrow">{number}</span><h2 tabIndex={-1}>{title}</h2><p>{subtitle}</p></div>;
}

export default function Home() {
  const [phase, setPhase] = useState(0);
  const [ready, setReady] = useState(false);
  const settings = useSiteSettings();
  const music = useCalmMusic(settings.musicVolume);
  const scrollTo = useSmoothScroll();
  const [today, setToday] = useState<Date>();
  const [selectedDate, setDate] = useState<Date>();
  const [selectedTime, setTime] = useState("");
  const [selectedFood, setFood] = useState("");
  const [selectedVibe, setVibe] = useState("");
  const [selectedLocation, setLocation] = useState("");
  const [confirmedPlan, setConfirmedPlan] = useState<{ date: string; time: string; food: string; vibe: string; location: string; amount: number } | null>(null);
  const food = settings.foods.find(item => item.id === selectedFood);
  const location = settings.locations.find(item => item.id === selectedLocation);
  const vibe = VIBES.find(item => item.id === selectedVibe);
  const foodLabel = food ? `${food.emoji} ${food.name}` : "";
  const locationLabel = location ? `${location.emoji} ${location.name}` : "";
  const vibeLabel = vibe ? `${vibe.emoji} ${vibe.name}` : "";
  const summaryRows = [["Date", dateText(selectedDate)], ["Time", formatTime(selectedTime)], ["Food", foodLabel], ["Vibe", vibeLabel], ["Location", locationLabel]];
  const ticketRows = confirmedPlan ? [["Date", confirmedPlan.date], ["Time", confirmedPlan.time], ["Food", confirmedPlan.food], ["Vibe", confirmedPlan.vibe], ["Location", confirmedPlan.location]] : summaryRows;
  const amountLabel = formatAmount(settings.reservationAmount);
  const confirmedAmountLabel = formatAmount(confirmedPlan?.amount ?? settings.reservationAmount);
  const [acceptedDate, setAccepted] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [noMessage, setNoMessage] = useState(false);
  const [burst, setBurst] = useState(0);
  const [continueReady, setContinueReady] = useState(false);
  const [saved, setSaved] = useState("");
  const [dateError, setDateError] = useState("");
  const hero = useRef<HTMLElement>(null);
  const cinema = useRef<HTMLElement>(null);
  const intermission = useRef<HTMLElement>(null);
  const cursor = useRef<HTMLDivElement>(null);
  const pendingScroll = useRef<string | null>(null);
  const state = useRef({ selectedDate, selectedTime, selectedFood, selectedVibe, selectedLocation, foodLabel, vibeLabel, locationLabel, acceptedDate, phase });
  state.current = { selectedDate, selectedTime, selectedFood, selectedVibe, selectedLocation, foodLabel, vibeLabel, locationLabel, acceptedDate, phase };
  // The invitation starts and stays animated without a Play/Pause control.
  const enabled = true;
  const gentle = false;
  const animate = true;

  const advance = useCallback((next: number, id: string) => {
    if (state.current.phase >= next) scrollTo(id, true);
    else { pendingScroll.current = id; setPhase(next); }
  }, [scrollTo]);

  useEffect(() => {
    setToday(todayDate());
    const t = setTimeout(() => setReady(true), 1050);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (pendingScroll.current) { const id = pendingScroll.current; pendingScroll.current = null; requestAnimationFrame(() => { ScrollTrigger.refresh(); void scrollTo(id, true); }); }
    if (phase === 1) { const t = setTimeout(() => setContinueReady(true), 1300); return () => clearTimeout(t); }
  }, [phase, scrollTo]);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.motion = animate ? "on" : "off";
    root.dataset.motionChoice = "play";
    let raf = 0;
    const update = () => {
      raf = 0;
      if (!animate || document.hidden) return;
      const h = window.innerHeight;
      if (hero.current) { const y = Math.max(0, -hero.current.getBoundingClientRect().top); hero.current.style.setProperty("--hero-progress", String(Math.min(y / h, 1))); }
      if (cinema.current) {
        const rect = cinema.current.getBoundingClientRect();
        const p = Math.min(1, Math.max(0, -rect.top / Math.max(1, rect.height - h)));
        cinema.current.style.setProperty("--scene-progress", String(p));
        cinema.current.style.setProperty("--scene-scale", String(1 + Math.sin(p * Math.PI * .86) * .52));
        cinema.current.style.setProperty("--scene-radius", `${Math.max(3, 44 - p * 65)}%`);
        cinema.current.style.setProperty("--scene-flash", String(Math.max(0, (p - .86) / .14)));
        cinema.current.style.setProperty("--scene-label", String(Math.max(0, 1 - p * 5)));

      }
      if (intermission.current) { const r = intermission.current.getBoundingClientRect(); const p = Math.min(1, Math.max(0, (h - r.top) / (h + r.height))); intermission.current.style.setProperty("--interlude", String(p)); }
    };
    const queue = () => { if (!raf) raf = requestAnimationFrame(update); };
    const visibility = () => {
      root.dataset.visible = document.hidden ? "no" : "yes";
      if (!document.hidden) queue();
    };
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("scroll", queue, { passive: true }); window.addEventListener("resize", queue);
    visibility();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("scroll", queue); window.removeEventListener("resize", queue); document.removeEventListener("visibilitychange", visibility); };
  }, [animate, phase]);

  useEffect(() => {
    if (!animate) return;
    gsap.registerPlugin(ScrollTrigger);
    const context = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>(".story-reveal").forEach(el => {
        gsap.fromTo(el, { y: 40, scale: .96, filter: "blur(8px)", opacity: 0 }, { y: 0, scale: 1, filter: "blur(0px)", opacity: 1, duration: .85, ease: "power3.out", scrollTrigger: { trigger: el, start: "top 94%", once: true } });
      });
    });
    return () => context.revert();
  }, [animate, phase]);

  useEffect(() => {
    if (!animate || !matchMedia("(pointer: fine)").matches) return;
    const move = (e: PointerEvent) => { if (cursor.current) { cursor.current.style.transform = `translate3d(${e.clientX}px,${e.clientY}px,0)`; cursor.current.classList.toggle("hovering", !!(e.target as HTMLElement).closest("button,label,a")); cursor.current.style.opacity = "1"; } };
    const leave = () => { if (cursor.current) cursor.current.style.opacity = "0"; };
    window.addEventListener("pointermove", move); document.addEventListener("pointerleave", leave);
    return () => { window.removeEventListener("pointermove", move); document.removeEventListener("pointerleave", leave); };
  }, [animate]);

  useEffect(() => {
    const context = (document as Document & { modelContext?: { registerTool: (tool: unknown, options: { signal: AbortSignal }) => void | Promise<void> } }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    Promise.resolve(context.registerTool({ name: "read_date_plan", description: "Read the current date invitation choices and whether the fictional date is confirmed. No real booking or payment is made.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute: (input: unknown) => { if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length) throw new Error("Expected an empty object"); const s = state.current; return { date: s.selectedDate ? dayKey(s.selectedDate) : null, time: formatTime(s.selectedTime) || null, food: s.foodLabel || null, vibe: s.vibeLabel || null, location: s.locationLabel || null, accepted: s.acceptedDate, confirmed: s.phase === 6, actualCharge: 0, currency: "LKR" }; } }, { signal: lifecycle.signal })).catch(() => {});
    return () => lifecycle.abort();
  }, []);

  const onNoAttempt = useCallback(() => setAttempts(n => n + 1), []);
  const sayYes = () => { setAccepted(true); setBurst(n => n + 1); advance(1, "celebration"); };
  const lockDate = () => { if (!selectedDate || !selectedTime) return; if (selectedDate < todayDate()) { setDateError("That day has passed. Pick another lovely day 💙"); return; } if (!isFutureDateTime(selectedDate, selectedTime)) { setDateError("That time has passed. Choose a later time or another day 💙"); return; } setDateError(""); advance(3, "food"); };
  const confirm = () => {
    if (!selectedDate || !isFutureDateTime(selectedDate, selectedTime)) { setDateError("Choose a future date and time before confirming."); void scrollTo("date", true); return; }
    if (!food) { void scrollTo("food", true); return; }
    if (!vibe || !location) { void scrollTo("vibe", true); return; }
    setConfirmedPlan({ date: dateText(selectedDate), time: formatTime(selectedTime), food: foodLabel, vibe: vibeLabel, location: locationLabel, amount: settings.reservationAmount });
    setBurst(n => n + 1); advance(6, "confirmed");
  };
  const replay = async () => {
    if (!await scrollTo("hello")) return;
    setPhase(0); setAccepted(false); setDate(undefined); setTime(""); setFood(""); setVibe(""); setLocation(""); setConfirmedPlan(null);
    setAttempts(0); setNoMessage(false); setContinueReady(false); setSaved(""); setBurst(0); setDateError("");
  };

  const saveCard = async () => {
    try {
      await document.fonts.ready;
      const portrait = new window.Image();
      portrait.src = STITCH_IMAGE;
      await portrait.decode();
      const canvas = document.createElement("canvas"); canvas.width = 1080; canvas.height = 1680;
      const c = canvas.getContext("2d"); if (!c) throw new Error("Canvas unavailable");
      const gradient = c.createLinearGradient(0, 0, 1080, 1680); gradient.addColorStop(0, settings.theme.background); gradient.addColorStop(1, settings.theme.accent); c.fillStyle = gradient; c.fillRect(0, 0, 1080, 1680);
      c.fillStyle = settings.theme.card; c.beginPath(); c.roundRect(75, 70, 930, 1540, 50); c.fill();
      const write = (text: string, x: number, y: number, size: number, color = "#163a5f", weight = "700", align: CanvasTextAlign = "left") => { c.fillStyle = color; c.font = `${weight} ${size}px "Nunito Variable", sans-serif`; c.textAlign = align; c.fillText(text, x, y, align === "right" ? 625 : 900); };
      write("SNOW MUCH LOVE", 540, 140, 26, "#568ab7", "800", "center");
      c.save(); c.beginPath(); c.roundRect(345, 175, 390, 420, 125); c.clip();
      c.drawImage(portrait, 0, 215, 720, 775, 345, 175, 390, 420); c.restore();
      write("Sandunika & me", 540, 690, 69, "#163a5f", "900", "center");
      write("OUR DATE", 540, 750, 33, "#6096bc", "800", "center");
      const rows = ticketRows.map(([label, value]) => [label.toUpperCase(), value]);
      rows.forEach(([label, val], i) => { write(label, 145, 826 + i * 78, 23, "#7893a9", "700"); write(val, 935, 826 + i * 78, label === "DATE" ? 32 : 37, "#28516f", "800", "right"); });
      c.strokeStyle = "#c7e2f2"; c.lineWidth = 3; c.setLineDash([10, 10]); c.beginPath(); c.moveTo(135, 1195); c.lineTo(945, 1195); c.stroke(); c.setLineDash([]);
      write("CONFIRMED", 540, 1290, 55, "#388bcc", "900", "center");
      write(`Rs. ${confirmedAmountLabel} — paid in unlimited affection`, 540, 1360, 28, "#68829a", "600", "center");
      write("No real payment. Just a very cute plan.", 540, 1415, 25, "#68829a", "500", "center");
      write("Stitch approves. So does my heart.", 540, 1530, 30, "#d385a8", "700", "center");
      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error("Could not create image")), "image/png"));
      const file = new File([blob], "sandunika-date-card.png", { type: "image/png" });
      if (matchMedia("(pointer: coarse)").matches && navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: "Our date, Sandunika 💙" }); setSaved("Your date card is ready 💙"); }
      else { const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "sandunika-date-card.png"; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 10000); setSaved("Date card saved. Keep it close 💙"); }
    } catch (e) { if (e instanceof Error && e.name === "AbortError") return; setSaved("Couldn't save this time — you can still screenshot your ticket 💙"); }
  };

  return <main className={`snow-world ${phase === 6 ? "finished" : ""}`} style={themeVariables(settings.theme)}>
    {!ready && <div className="loading-intro"><Snowflake size={34} /><p>something cute is loading...</p></div>}
    <ScrollVideoBackground enabled={enabled} gentle={gentle} revision={phase} speed={settings.videoSpeed} />
    <SnowParticles /><Confetti burst={burst} />
    <div className="snow-cursor" ref={cursor} aria-hidden="true"><Heart size={17} fill="#bbdefb" /></div>
    <header className="site-header"><a className="wordmark" href="#" onClick={e => { e.preventDefault(); void scrollTo("hello"); }} aria-label="Snow much love, back to top"><Snowflake size={25} strokeWidth={1.6} /><span>snow much <b>love.</b></span></a><span className="header-note">a little courage. a lot of love.</span><div className="header-controls"><button className="icon-button music-button" data-music-toggle onClick={music.toggle} disabled={music.status === "unavailable"} aria-label={music.status === "playing" ? "Mute calm music" : "Play calm music"} title={music.status === "playing" ? "Calm music is playing" : "Play calm music"} aria-pressed={music.status === "playing"}>{music.status === "playing" ? <Volume2 size={18} /> : <VolumeX size={18} />}</button></div></header>
    <>
      <section className="hero" ref={hero} id="hello">
        <div className="hero-copy"><span className="eyebrow hero-eyebrow"><span className="tiny-heart">♥</span> A LITTLE INVITATION, JUST FOR YOU</span><h1><span className="hey">Hey, {HER_NAME}...</span>I have a <span className="tiny-word">tiny<svg viewBox="0 0 170 14" aria-hidden="true"><path d="M4 10 Q 70 -2 166 8" /></svg></span><br />question for you<span className="heading-heart">♡</span></h1><p className="hero-sub">but you have to promise<br className="mobile-break" /> not to run away 😭</p><button className="primary hero-cta magnetic" onClick={() => scrollTo("cinema")} onPointerMove={e => { if (animate && e.pointerType === "mouse") { const r = e.currentTarget.getBoundingClientRect(); e.currentTarget.style.setProperty("--mx", `${(e.clientX - r.left - r.width / 2) * .07}px`); e.currentTarget.style.setProperty("--my", `${(e.clientY - r.top - r.height / 2) * .12}px`); } }} onPointerLeave={e => { e.currentTarget.style.setProperty("--mx", "0px"); e.currentTarget.style.setProperty("--my", "0px"); }}>What's the question? <ArrowRight size={19} /></button><div className="hero-fine"><Heart size={13} /> made with butterflies & a tiny bit of panic</div></div>
        <div className="hero-visual"><span className="visual-spark spark-one">✧</span><span className="visual-spark spark-two">✦</span><div className="video-outline" /><div className="hero-video-wrap"><LoopingStitch enabled={enabled} muted={true} label="Our little blue friend playing happily in the snow" /></div><div className="love-bubble">hi, you. <span>💙</span></div><div className="video-caption"><span>currently:</span> gathering the courage 🥹</div><span className="handwritten hero-hand">only for you, Sandunika.</span><svg className="hand-arrow" viewBox="0 0 100 55" aria-hidden="true"><path d="M6 42 Q63 59 78 8 M66 17 L79 6 83 23" /></svg></div>
        <button className="scroll-hint" onClick={() => scrollTo("cinema")}><span className="scroll-pill"><ArrowDown size={16} /></span><span>scroll for the surprise</span></button><div className="hero-index" aria-hidden="true">01 <span>—</span> A LITTLE HELLO</div>
      </section>
      <section className="cinema" ref={cinema} id="cinema" aria-label="A snowy background adventure for Sandunika"><div className="cinema-sticky"><div className="cinema-label"><span className="eyebrow">SANDUNIKA, THIS LITTLE WORLD IS YOURS</span><h2>A little closer...</h2><span className="handwritten">keep scrolling ♡</span></div><span className="scene-heart h-one" aria-hidden="true">♡</span><span className="scene-heart h-two" aria-hidden="true">♡</span><button className="skip-scene" onClick={() => scrollTo("question", true)}>to the tiny question <ArrowDown size={15} /></button></div></section>
      <section className="story-section question-section" id="question"><div className="question-card story-reveal"><span className="question-sticker">🥹</span><span className="eyebrow">SANDUNIKA... OKAY. DEEP BREATH.</span><h2 tabIndex={-1}>Will you go on a<br />date with me? <span>💙</span></h2><p>just you, me, and a really good excuse to smile.</p><div className="answer-arena"><button className="primary yes-button" style={{ "--yes-scale": 1 + Math.min(attempts, 6) * .035 } as CSSProperties} onClick={sayYes}><Heart size={21} fill="currentColor" /> YESSS!</button><EscapingNoButton enabled={enabled} gentle={gentle} active={!acceptedDate} onAttempt={onNoAttempt} onDecline={() => setNoMessage(true)} /></div><p className="no-note" role="status">{noMessage ? "That's okay. No pressure — the snow and good vibes are still yours 💙" : attempts ? "the no button is having commitment issues 🙈" : "psst... one of these buttons is a little shy."}</p></div></section>
      {phase >= 1 && <section className="story-section celebration-section" id="celebration"><div className="celebration-content story-reveal"><span className="celebrate-emoji">😭💙</span><span className="eyebrow">SANDUNIKA SAID YES. I REPEAT: SANDUNIKA SAID YES.</span><h2 tabIndex={-1}>WAIT... YOU ACTUALLY<br />SAID <span className="pink-text">YES?!</span></h2><p className="big-copy">I was emotionally prepared for rejection 😂</p><p>okay okay... let's plan this properly.</p><button className={`primary continue-button ${continueReady ? "show" : ""}`} disabled={!continueReady} onClick={() => advance(2, "date")}>continue <ArrowDown size={19} /></button><span className="handwritten">best plot twist ever.</span></div></section>}
      {phase >= 2 && <section className="story-section date-section" id="date"><div className="planner-shell story-reveal"><SectionIntro number="01 / OUR LITTLE PLAN" title={<>So... when are<br />you free? <span>🗓️</span></>} subtitle="pick a day before I start overthinking this" /><div className="calendar-card">{today && <Calendar mode="single" required selected={selectedDate} onSelect={d => { setDate(d); setDateError(""); }} disabled={{ before: today }} startMonth={new Date(today.getFullYear(), today.getMonth())} showOutsideDays={false} className="date-calendar" />}<div className="selected-date" aria-live="polite"><Heart size={14} fill="currentColor" />{selectedDate ? dateText(selectedDate) : "a little day, just for us"}</div></div><h3 className="time-title">Perfect. Now what time? <span>⏰</span></h3><RadioGroup value={selectedTime} onValueChange={v => { setTime(v); setDateError(""); }} className="time-chips" aria-label="Date time">{TIMES.map(time => <label key={time} className={`time-chip ${selectedTime === time ? "selected" : ""}`}><RadioGroupItem value={time} aria-label={formatTime(time)} className="choice-radio" /><span>{formatTime(time)}</span></label>)}</RadioGroup><div className="custom-time"><label htmlFor="custom-time">Or choose any time you like</label><Input id="custom-time" type="time" step="60" value={selectedTime} onChange={e => { setTime(e.target.value); setDateError(""); }} aria-describedby="chosen-time" /><span id="chosen-time" aria-live="polite">{selectedTime ? `Our time: ${formatTime(selectedTime)}` : "Morning, afternoon, or late-night magic."}</span></div><p className="field-error" role="status">{dateError}</p><button className="primary next-button" disabled={!selectedDate || !selectedTime} onClick={lockDate}>lock it in <Heart size={18} /></button></div></section>}
      {phase >= 3 && <section className="story-section food-section" id="food"><div className="planner-shell wide story-reveal"><SectionIntro number="02 / THE IMPORTANT STUFF" title={<>Okay... what are<br />we eating? <span>👀</span></>} subtitle="choose wisely, this is very serious business" /><ChoiceCards items={settings.foods} value={selectedFood} onChange={setFood} label="Choose our food" /><p className="selection-status" role="status">{selectedFood ? "Excellent choice 😌" : "the way to my heart is probably on this list"}</p><button className="primary next-button" disabled={!food} onClick={() => advance(4, "vibe")}>next surprise <ArrowRight size={18} /></button><button className="text-button back-button" onClick={() => scrollTo("date", true)}><ArrowLeft size={15} /> change our day</button></div></section>}
      {phase >= 4 && <section className="story-section vibe-section" id="vibe"><div className="planner-shell wide story-reveal"><SectionIntro number="03 / A MEMORY IN THE MAKING" title={<>Choose our vibe <span>✨</span></>} subtitle="the company is already perfect. just saying." /><ChoiceCards items={VIBES} value={selectedVibe} onChange={setVibe} label="Choose our date vibe" /><p className="selection-status" role="status">{selectedVibe ? `${vibe?.name}? It's a date. Almost... 💙` : "a little adventure, or a little cozy?"}</p><div className="location-picker"><h3>And where shall we go? <span aria-hidden="true">📍</span></h3><p>pick a little place for our big smiles</p><ChoiceCards items={settings.locations} value={selectedLocation} onChange={setLocation} label="Choose our location" /></div><button className="primary next-button" disabled={!vibe || !location} onClick={() => advance(5, "intermission")}>one tiny detail left <ArrowRight size={18} /></button><button className="text-button back-button" onClick={() => scrollTo("food", true)}><ArrowLeft size={15} /> rethink the snacks</button></div></section>}
      {phase >= 5 && <><section className="story-section intermission" ref={intermission} id="intermission"><span className="eyebrow">A SMALL MOMENT OF HAPPINESS</span><div className="intermission-card"><LoopingStitch enabled={enabled} muted={true} label="Our little friend is celebrating" /><span>me, trying to act normal rn.</span><i className="orbit-heart">♡</i></div><h2 tabIndex={-1}>this is getting<br /><span className="pink-text">suspiciously cute...</span></h2><p>but there's one tiny detail left 👀</p><button className="text-button" onClick={() => scrollTo("agreement", true)}>the very official paperwork <ArrowDown size={17} /></button></section><section className="story-section agreement-section" id="agreement"><div className="agreement-card story-reveal"><div className="agreement-top"><Snowflake size={26} /><span>DEPARTMENT OF VERY CUTE PLANS</span><Heart size={22} /></div><img className="agreement-stitch" src={STITCH_IMAGE} alt="Stitch smiling in the snow" width="110" height="110" /><h2 tabIndex={-1}>Official Date<br />Agreement<span className="trademark">™</span> 💙</h2><p className="agreement-sub">a very serious little agreement with {HER_NAME}</p><dl className="summary-list">{summaryRows.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><button className="text-button edit-plan" onClick={() => scrollTo("date", true)}>edit our little plan</button><div className="fee-block"><span className="eyebrow">DATE RESERVATION FEE</span><div className="price"><span>Rs.</span> {amountLabel}<span className="price-spark">✦</span></div><p>one-time fee • non-refundable<br />paid in unlimited affection 😂</p><span className="fee-note">Taxes include: one hug, one good conversation<br />& no ghosting.</span></div><button className="primary pay-button" onClick={confirm}>Pay Rs. {amountLabel} & Confirm <Heart size={19} fill="currentColor" /></button><div className="pretend-note"><Sparkles size={13} /> pretend payment. real butterflies.</div>{(!food || !location) && <p className="field-error">Some options have changed. Tap confirm to review your choices.</p>}</div></section></>}
      <footer className="site-footer"><Snowflake size={15} /><span>a tiny story, with you in it.</span><Heart size={14} /></footer>
    </>
    {phase === 6 && <section className="confirmation-section" id="confirmed"><div className="confirmed-heading"><span className="eyebrow">SANDUNIKA, IT'S OFFICIAL. I'M SMILING.</span><h1>DATE CONFIRMED! <span>💙✨</span></h1><p>Best Rs. {confirmedAmountLabel} decision<br className="mobile-break" /> you'll never actually have to pay 😂</p></div><div className="ticket"><div className="ticket-top"><span>ADMIT TWO</span><Snowflake size={23} /><span>ONE CUTE PLAN</span></div><div className="ticket-art"><img src={STITCH_IMAGE} alt="Stitch celebrating our date in the snow" width="720" height="1280" /><span className="stitch-approval">Stitch approves ♡</span></div><h2>OUR DATE <span>🎟️</span></h2><p className="ticket-for">{HER_NAME} <span>&</span> me</p><p className="ticket-sub">a little love. a little Stitch magic.</p><dl className="summary-list">{ticketRows.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><div className="ticket-stub"><span className="confirmed-stamp"><Check size={23} /> CONFIRMED <Heart size={20} fill="currentColor" /></span><span>paid in unlimited affection</span></div></div><p className="screenshot-note">Screenshot this before you change your mind 😌</p><button className="primary" onClick={saveCard}><Download size={18} /> Save our date card 📸</button><p className="save-status" role="status">{saved}</p><button className="text-button" onClick={replay}><RotateCcw size={16} /> Replay the chaos</button><span className="handwritten final-note">can't wait to see you, Sandunika.</span></section>}
  </main>;
}
