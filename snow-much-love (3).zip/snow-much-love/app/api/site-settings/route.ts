import { NextResponse } from "next/server";
import { DEFAULT_SETTINGS } from "@/lib/site-settings";
export const dynamic = "force-dynamic";
export async function GET() {
  return NextResponse.json({ settings: DEFAULT_SETTINGS, revision: "default" }, { headers: { "Cache-Control": "no-store" } });
}
export async function PUT() {
  return NextResponse.json({ error: "Use the Firebase admin to save settings." }, { status: 401, headers: { "Cache-Control": "no-store" } });
}
