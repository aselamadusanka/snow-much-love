import { NextResponse } from "next/server";
export const dynamic = "force-dynamic";
export async function GET() {
  return NextResponse.json({ authenticated: false, signedIn: false, configured: false, signInHref: "", signOutHref: "" }, { headers: { "Cache-Control": "no-store" } });
}
