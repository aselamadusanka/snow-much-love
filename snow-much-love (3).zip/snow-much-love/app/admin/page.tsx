"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowUp, Check, Cloud, Banknote, ExternalLink, LockKeyhole, LogOut, MapPin, Palette, Plus, Save, Snowflake, Trash2, Utensils } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CHOICE_COLORS, DEFAULT_SETTINGS, settingsSchema, snapshotSchema, formatAmount, themeVariables, type Choice, type SiteSettings } from "@/lib/site-settings";
import { AdminThemeEditor } from "@/components/admin-theme-editor";
import { useFirebaseAdmin } from "@/hooks/use-firebase-admin";
import { firebaseErrorMessage, readFirebaseSettings, saveFirebaseSettings } from "@/lib/firebase-settings";
import "./studio.css";

type Session = { authenticated: boolean; signedIn: boolean; configured: boolean; signInHref: string; signOutHref: string };
export const dynamic = "force-dynamic";
async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(path, { signal: AbortSignal.timeout(10000), ...options, cache: "no-store", headers: { "Content-Type": "application/json", ...options?.headers } });
  const data = await response.json() as T & { error?: string };
  if (!response.ok) throw Object.assign(new Error(data.error || "Something went wrong. Please try again."), { status: response.status });
  return data;
}

function ChoiceEditor({ title, items, onChange }: { title: string; items: Choice[]; onChange: (items: Choice[]) => void }) {
  const update = (id: string, patch: Partial<Choice>) => onChange(items.map(item => item.id === id ? { ...item, ...patch } : item));
  const move = (index: number, direction: number) => { const next = [...items]; [next[index], next[index + direction]] = [next[index + direction], next[index]]; onChange(next); };
  return <div className="choice-editor">
    <div className="studio-section-heading"><div><h2>{title}</h2><p>Edit names, emojis and card colors. Use the arrows to change their order.</p></div><span className="studio-count">{items.length} options</span></div>
    <div className="studio-rows">{items.map((item, index) => <div className="studio-row" key={item.id}>
      <div className={`studio-option-preview ${item.color}`} aria-hidden="true">{item.emoji || "♡"}</div>
      <div className="studio-field"><Label htmlFor={`${item.id}-name`}>Name</Label><Input id={`${item.id}-name`} value={item.name} maxLength={40} onChange={e => update(item.id, { name: e.target.value })} placeholder="A lovely choice" /></div>
      <div className="studio-field emoji-field"><Label htmlFor={`${item.id}-emoji`}>Emoji / icon</Label><Input id={`${item.id}-emoji`} value={item.emoji} maxLength={24} onChange={e => update(item.id, { emoji: e.target.value })} placeholder="🍕" /></div>
      <div className="studio-field color-field"><Label htmlFor={`${item.id}-color`}>Card color</Label><NativeSelect id={`${item.id}-color`} value={item.color} onChange={e => update(item.id, { color: e.target.value as Choice["color"] })}>{CHOICE_COLORS.map(color => <NativeSelectOption key={color} value={color}>{color}</NativeSelectOption>)}</NativeSelect></div>
      <div className="studio-row-actions"><Button type="button" variant="ghost" size="icon" disabled={index === 0} aria-label={`Move ${item.name || "option"} up`} onClick={() => move(index, -1)}><ArrowUp /></Button><Button type="button" variant="ghost" size="icon" disabled={index === items.length - 1} aria-label={`Move ${item.name || "option"} down`} onClick={() => move(index, 1)}><ArrowDown /></Button><Button type="button" variant="ghost" size="icon" disabled={items.length <= 1} className="remove-option" aria-label={`Remove ${item.name || "option"}`} onClick={() => onChange(items.filter(option => option.id !== item.id))}><Trash2 /></Button></div>
    </div>)}</div>
    <Button type="button" variant="outline" className="add-option" disabled={items.length >= 16} onClick={() => onChange([...items, { id: `choice-${crypto.randomUUID()}`, name: "", emoji: title === "Food menu" ? "🍽️" : "📍", color: "blue" }])}><Plus /> Add {title === "Food menu" ? "food" : "location"}</Button>
  </div>;
}

async function withTimeout<T>(promise: Promise<T>, milliseconds: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  try { return await Promise.race([promise, new Promise<T>((_, reject) => { timer = setTimeout(() => reject(new Error("Firebase is taking too long. Check your connection and project setup.")), milliseconds); })]); }
  finally { clearTimeout(timer!); }
}

export default function AdminPage() {
  const firebase = useFirebaseAdmin();
  const [session, setSession] = useState<Session | null>(null);
  const [draft, setDraft] = useState<SiteSettings | null>(null);
  const [saved, setSaved] = useState("");
  const [revision, setRevision] = useState("");
  const [source, setSource] = useState<"firebase" | "site">("site");
  const [cloud, setCloud] = useState<{ status: "checking" | "ready" | "unavailable"; exists: boolean; error: string }>({ status: "checking", exists: false, error: "" });
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [conflict, setConflict] = useState(false);
  const knownCloud = useRef(false);

  const load = useCallback(async () => {
    const [auth, local, remote] = await Promise.allSettled([
      request<Session>("/api/admin/session"),
      request<unknown>("/api/site-settings"),
      withTimeout(readFirebaseSettings(), 6000),
    ]);
    setSession(auth.status === "fulfilled" ? auth.value : null);
    if (remote.status === "rejected" && knownCloud.current) throw new Error("Firebase could not reload. Your current edits are safe; please retry.");
    const cloudSnapshot = remote.status === "fulfilled" ? remote.value : null;
    const localSnapshot = local.status === "fulfilled" ? snapshotSchema.safeParse(local.value) : null;
    const snapshot = cloudSnapshot || (localSnapshot?.success ? localSnapshot.data : null)
      || (remote.status === "fulfilled" ? { settings: structuredClone(DEFAULT_SETTINGS), revision: "default" } : null);
    if (cloudSnapshot) knownCloud.current = true;
    setCloud({ status: remote.status === "fulfilled" ? "ready" : "unavailable", exists: !!cloudSnapshot, error: remote.status === "rejected" ? firebaseErrorMessage(remote.reason) : "" });
    if (snapshot) {
      setDraft(snapshot.settings); setSaved(JSON.stringify(snapshot.settings)); setRevision(snapshot.revision);
      setSource(cloudSnapshot ? "firebase" : "site"); setConflict(false);
    } else {
      setDraft(structuredClone(DEFAULT_SETTINGS)); setSaved(JSON.stringify(DEFAULT_SETTINGS)); setRevision("default");
    }
    setLoaded(true);
  }, []);
  useEffect(() => { void load().catch(reason => { setError((reason as Error).message); setLoaded(true); }); }, [load]);
  const dirty = !!draft && JSON.stringify(draft) !== saved;
  const importing = !!firebase.user && cloud.status === "ready" && !cloud.exists;
  const firebaseSave = !!firebase.user && cloud.status === "ready";
  const siteSave = !!session?.authenticated && !cloud.exists && source === "site";
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); };
    window.addEventListener("beforeunload", warn); return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);

  const signIn = async () => {
    setBusy(true); setError(""); setMessage("");
    try {
      await firebase.signIn();
      // Refresh connection state without discarding a draft already being edited.
      const snapshot = await withTimeout(readFirebaseSettings(), 6000);
      setCloud({ status: "ready", exists: !!snapshot, error: "" });
      if (snapshot) {
        knownCloud.current = true;
        if (dirty) { setConflict(true); setError("Firebase has saved settings. Reload them before editing this version."); }
        else { setDraft(snapshot.settings); setSaved(JSON.stringify(snapshot.settings)); setRevision(snapshot.revision); setSource("firebase"); }
      }
    } catch (reason) { setError(firebaseErrorMessage(reason)); }
    finally { setBusy(false); }
  };
  const save = async () => {
    const result = settingsSchema.safeParse(draft);
    if (!result.success) { setError(result.error.issues[0]?.message || "Check each option before saving."); return; }
    if (conflict) { setError("Reload the saved settings before saving."); return; }
    setBusy(true); setError(""); setMessage("");
    try {
      let snapshot;
      if (firebaseSave) {
        snapshot = await saveFirebaseSettings(result.data, cloud.exists ? revision : "default");
        knownCloud.current = true; setSource("firebase"); setCloud({ status: "ready", exists: true, error: "" });
        setMessage("Saved to Firebase. Open invitations update in real time.");
      } else if (siteSave) {
        snapshot = snapshotSchema.parse(await request("/api/site-settings", { method: "PUT", body: JSON.stringify({ settings: result.data, revision }) }));
        setMessage("Saved to the live invitation. Firebase sync is still waiting for setup.");
      } else throw new Error("Sign in with your Google account and finish Firebase setup before saving.");
      setDraft(snapshot.settings); setRevision(snapshot.revision); setSaved(JSON.stringify(snapshot.settings)); setConflict(false);
    } catch (reason) {
      const problem = reason as Error & { status?: number };
      setError(firebaseErrorMessage(reason)); setConflict(problem.status === 409);
      if (problem.status === 401) setSession(value => value ? { ...value, authenticated: false } : value);
    } finally { setBusy(false); }
  };
  const retry = async () => {
    setBusy(true); setError("");
    try {
      const snapshot = await withTimeout(readFirebaseSettings(), 6000);
      setCloud({ status: "ready", exists: !!snapshot, error: "" });
      if (snapshot && (source !== "firebase" || snapshot.revision !== revision)) {
        knownCloud.current = true; setConflict(true); setError("Firebase settings are available. Reload saved settings to continue.");
      } else setMessage(snapshot ? "Firebase is connected." : "Firebase is ready. Sign in with Google, then save to connect your invitation.");
    } catch (reason) { setCloud(value => ({ ...value, status: "unavailable", error: firebaseErrorMessage(reason) })); setError(firebaseErrorMessage(reason)); }
    finally { setBusy(false); }
  };
  const signOut = async () => {
    setBusy(true); setError("");
    try { await firebase.signOut(); if (session?.signedIn) window.location.assign(session.signOutHref); }
    catch (reason) { setError(firebaseErrorMessage(reason)); }
    finally { setBusy(false); }
  };

  if (!loaded || !draft || (!firebase.ready && !session?.authenticated)) return <main className="studio-root studio-center"><div className="studio-auth"><Snowflake size={36} /><h1>Your little studio</h1><p role="status">{error || "Opening your invitation settings…"}</p>{error && <Button onClick={() => { setError(""); void load().catch(reason => setError(reason.message)); }}>Try again</Button>}</div></main>;
  if (!firebase.user && !session?.authenticated) return <main className="studio-root studio-center"><div className="studio-auth"><div className="studio-lock"><LockKeyhole size={27} /></div><span className="studio-eyebrow">SNOW MUCH LOVE · PRIVATE ADMIN</span><h1>Welcome back, Asela.</h1><p>Sign in with your Google account to manage your invitation in Firebase.</p>
    <Button className="studio-google" onClick={signIn} disabled={busy}>{busy ? "Connecting…" : "Continue with Google"}<ExternalLink size={17} /></Button>
    {error && <p className="studio-message error" role="alert">{error}</p>}
    {session?.configured && <a className="studio-back" href={session.signedIn ? session.signOutHref : session.signInHref} target="_top">{session.signedIn ? "Switch ChatGPT account" : "Use my existing ChatGPT admin"}</a>}
    <a className="studio-back" href="/">Back to the invitation</a><p className="studio-login-note">Only the approved owner can save changes.</p></div></main>;

  return <main className="studio-root">
    <header className="studio-header"><a href="/" className="studio-brand"><Snowflake /><span>snow much <b>love.</b><small>YOUR INVITATION STUDIO</small></span></a><div className="studio-header-actions"><a href="/" target="_blank" rel="noreferrer" className="studio-open">Open invitation <ExternalLink size={16} /></a><Button variant="ghost" onClick={signOut} disabled={busy || dirty} title={dirty ? "Save or discard changes before signing out" : "Sign out"}><LogOut size={17} /> Sign out</Button></div></header>
    <div className="studio-intro"><div><span className="studio-eyebrow">FOR SANDUNIKA, WITH LOVE</span><h1>A few little details.<br />A very personal date.</h1><p>Edit your menu, places, colors and playful reservation amount.</p></div><div className="studio-save-box"><span className={dirty || importing ? "unsaved" : "saved"}>{dirty ? "Unsaved changes" : importing ? "Ready to connect Firebase" : <><Check size={15} /> All changes saved</>}</span><Button onClick={save} disabled={busy || conflict || (!dirty && !importing) || (!firebaseSave && !siteSave)}><Save /> {busy ? "One moment…" : importing ? "Save & connect Firebase" : "Save changes"}</Button></div></div>
    <div className={`studio-cloud ${source === "firebase" && cloud.status === "ready" ? "connected" : "pending"}`}>
      <div><Cloud size={23} /><div><strong>{source === "firebase" && cloud.status === "ready" ? "Firebase connected" : cloud.status === "ready" ? "Firebase is ready" : "Firebase setup needed"}</strong><p>{firebase.user ? `Google account: ${firebase.user.email}` : "Connect your Google account to save settings in Firebase."}{!cloud.exists && " Your current invitation is still available."}</p></div></div>
      <div className="studio-cloud-actions">{!firebase.user && <Button variant="outline" disabled={busy} onClick={signIn}>Connect Google</Button>}<Button variant="ghost" disabled={busy} onClick={retry}>Check connection</Button></div>
    </div>
    {cloud.status === "unavailable" && <details className="studio-setup"><summary>Finish Firebase setup</summary><p>{cloud.error}</p><ol><li>Enable Google under Firebase Authentication → Sign-in method.</li><li>Add this website’s domain under Authentication → Settings → Authorized domains.</li><li>Create a Cloud Firestore database and publish the <code>firestore.rules</code> included in your ZIP.</li><li>Connect Google here, then choose “Save & connect Firebase”.</li></ol><p>Your foods, locations, theme and amount will then sync through Firebase.</p></details>}
    {(error || message) && <div className={`studio-message ${error ? "error" : "success"}`} role={error ? "alert" : "status"}>{error || message}{conflict && <Button variant="outline" disabled={busy} onClick={() => { setBusy(true); setError(""); void load().catch(reason => setError(reason.message)).finally(() => setBusy(false)); }}>Reload saved settings</Button>}</div>}
    <div className="studio-workspace"><section className="studio-panel"><fieldset disabled={busy} className="studio-fieldset"><Tabs defaultValue="foods"><TabsList className="studio-tabs" aria-label="Invitation settings"><TabsTrigger value="foods"><Utensils /> Foods</TabsTrigger><TabsTrigger value="locations"><MapPin /> Locations</TabsTrigger><TabsTrigger value="theme"><Palette /> Themes</TabsTrigger><TabsTrigger value="amount"><Banknote /> Amount</TabsTrigger></TabsList>
      <TabsContent value="foods"><ChoiceEditor title="Food menu" items={draft.foods} onChange={foods => setDraft({ ...draft, foods })} /></TabsContent>
      <TabsContent value="locations"><ChoiceEditor title="Date locations" items={draft.locations} onChange={locations => setDraft({ ...draft, locations })} /></TabsContent>
      <TabsContent value="theme"><AdminThemeEditor draft={draft} onChange={setDraft} /></TabsContent>
      <TabsContent value="amount"><div className="studio-section-heading"><div><h2>One very cute amount</h2><p>Change the playful reservation fee throughout the invitation and date card.</p></div></div><div className="studio-fee-preview"><span>DATE RESERVATION FEE</span><strong>Rs. {formatAmount(draft.reservationAmount)}</strong><p>paid in unlimited affection ♡</p></div><div className="studio-field studio-amount-field"><Label htmlFor="reservation-amount">Reservation amount (LKR)</Label><Input id="reservation-amount" type="number" inputMode="numeric" min={0} max={1000000} step={1} value={draft.reservationAmount} onChange={e => setDraft({ ...draft, reservationAmount: Number(e.target.value) })} aria-describedby="amount-help" /><p id="amount-help">Use a whole amount from Rs. 0 to Rs. 1,000,000. This is a pretend fee; no real payment is collected.</p></div><div className="studio-fee-suggestions">{[5000, 10000, 15000, 25000].map(amount => <Button key={amount} variant="outline" aria-pressed={draft.reservationAmount === amount} onClick={() => setDraft({ ...draft, reservationAmount: amount })}>Rs. {formatAmount(amount)}</Button>)}</div></TabsContent>
    </Tabs></fieldset></section>
    <aside className="studio-preview-wrap"><span className="studio-eyebrow">YOUR LIVE PREVIEW</span><div className="studio-preview" style={themeVariables(draft.theme)}><span className="preview-heart">♡</span><img src="/images/stitch-sandunika.jpg" alt="Stitch in the snow" width="96" height="96" /><p>Hey, Sandunika…</p><h2>A little date.<br />Our kind of magic.</h2><div className="preview-options">{draft.foods.slice(0, 3).map(item => <span key={item.id}>{item.emoji} {item.name || "Your food"}</span>)}</div><div className="preview-location">{draft.locations[0]?.emoji} {draft.locations[0]?.name || "Our little place"}</div><span className="preview-button">Confirm · Rs. {formatAmount(draft.reservationAmount)} ♡</span></div><p className="studio-preview-note">Save changes, then check the invitation in another tab. Saved Firebase settings update in real time.</p>{dirty && <Button variant="ghost" className="studio-reload" onClick={() => { setDraft(JSON.parse(saved) as SiteSettings); setError(""); setMessage(""); }}>Discard unsaved changes</Button>}</aside></div>
    <footer className="studio-footer"><LockKeyhole size={14} /> Only the approved owner can save changes.</footer>
  </main>;
}
