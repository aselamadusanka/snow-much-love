import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sandunika, a tiny question for you 💙",
  description: "Sandunika, a little courage, a lot of love, and one very important question. A snowy date invitation with Stitch, made just for you.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
