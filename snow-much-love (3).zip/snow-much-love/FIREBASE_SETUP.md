# Snow much love — Firebase setup

The app is configured for your Firebase project **snow-much-love**. The invitation’s shared settings live in the Cloud Firestore document **siteSettings/public**. Google sign-in protects editing; visitors can only read the public invitation settings.

Your web configuration is included in `lib/firebase-config.ts`. It identifies the Firebase app; it does not grant permission to enable products or publish database rules. Those steps require access to your Firebase console.

## One-time setup

1. Open your Firebase console and select **snow-much-love**.
2. Under **Authentication → Sign-in method**, enable **Google**. Choose the project’s support email if Firebase asks for it.
3. Under **Authentication → Settings → Authorized domains**, add:
   - `snow-much-love.aselamadusanka-atcur.chatgpt.site`
   - `localhost` for local development
   - Your eventual production domain if you host the ZIP somewhere else.
4. Open **Firestore Database**. If no database exists, create a **Standard / Native mode** database with the default database ID. Choose a suitable location and begin in production mode.
5. Open the database’s **Rules** tab and publish `firestore.rules` from this project. For an existing database with other applications, merge the `siteSettings/public` match and helper functions into its current rules instead of deleting unrelated rules.
6. Open your website’s `/admin` page and choose **Continue with Google** (or **Connect Google** inside the existing studio).
7. Use **aselamadusanka.atcurryking@gmail.com**. The supplied rules accept only that verified Google account. If a different account should own the invitation, deliberately change the owner email in the rules before publishing them.
8. Choose **Save & connect Firebase**. This copies your current invitation settings to Firebase on the first save. Subsequent saves update that same document.

If you already use the Firebase CLI, you can publish these rules from this directory after signing in:

```sh
firebase deploy --only firestore:rules --project snow-much-love
```

Do not enable public writes or use Firestore’s open test rules. No service-account key is required in this project.

## How to check it

- The studio should show **Firebase connected** after a successful save.
- Open the invitation in another tab. Change a food or theme, then save. The other tab updates through a Firestore listener.
- In the **Amount** tab, try Rs. 15,000. The agreement, confirm button, final heading and downloaded date image use the new amount.
- A confirmed date keeps the amount it was confirmed with, even if the admin changes it later.
- An anonymous or different Google account must not be able to write `siteSettings/public`.

## Themes

Choose **Snow Blue**, **Rose Pink**, **Lavender**, or **Custom**. Editing any color switches to Custom. Your custom palette is preserved when you try one of the presets and return to Custom.

## Connection messages

- **Unauthorized domain:** add the exact site hostname to Authentication → Settings → Authorized domains.
- **Sign-in provider not enabled:** enable Google in Authentication.
- **Permission denied:** publish the supplied Firestore rules and use the approved account.
- **Firebase setup needed:** the app is configured, but the connection has not been verified. Use **Check connection** after completing setup.
- **Settings changed in another session:** reload the saved version before editing. This prevents one admin tab from overwriting another.

On the existing ChatGPT Site, the previous owner-only studio remains available through **Use my existing ChatGPT admin** while Firebase is being set up. It can save the new themes and amount to the current Site. These saves explicitly report that Firebase sync is pending. Once Firebase has a settings document, the invitation uses it as its shared settings source.

The downloadable Next.js project uses Firebase for admin writes and includes the original defaults for its first load. It does not depend on a ChatGPT account, Cloudflare D1 or the Sites runtime.

No real payment or booking is made. Personal date selections stay in the visitor’s page; only invitation configuration is saved to Firebase. The Firebase Analytics identifier is retained in the configuration, but analytics collection is not needed or enabled for the admin connection.

Official references: [Firebase web setup](https://firebase.google.com/docs/web/setup), [Google sign-in](https://firebase.google.com/docs/auth/web/google-signin), [Firestore listeners](https://firebase.google.com/docs/firestore/query-data/listen), [Firestore security rules](https://firebase.google.com/docs/firestore/security/rules-conditions).
