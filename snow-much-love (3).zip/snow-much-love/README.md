# Snow much love · Firebase edition

A complete Next.js invitation for Sandunika, including all original video, image, scroll-frame and local font assets.

## Run locally

Use Node.js 22.13 or later and pnpm 11.25.0 (the version specified in package.json).

```sh
pnpm install
pnpm dev
```

Open http://localhost:3000 and http://localhost:3000/admin.

```sh
pnpm build
pnpm start
```

## Firebase setup

Read **FIREBASE_SETUP.md**. Your supplied Firebase web configuration is already included. Enable Google Authentication, authorize the site domain, create the Firestore database, and publish the included rules. Sign in with the approved Google account and save once from the admin to create the shared settings document.

The app uses a real Firestore listener and transactions for shared settings. Until Firebase setup is complete, the invitation displays its original defaults and admin saves require Firebase. There is no local-only storage pretending to sync between devices.

## Included changes

- Calm original background music after the first interaction, with mute control.
- Smooth button scrolling and continuously drifting, scroll-responsive background footage.
- Any custom time, food and location choices with editable emojis.
- A clearly highlighted escaping NO button, with keyboard access.
- Google/Firebase admin with food, location, theme, music and motion editing.
- Snow Blue, Rose Pink and Lavender themes, plus a saved custom palette.
- Editable reservation amount throughout the invitation and downloadable date card.
- The final Stitch card includes Sandunika’s name and the confirmed date choices.

No real payment, booking or outgoing message is made. Personal date choices remain in the visitor’s page. Only invitation settings are stored in Firebase.

## Hosting

This export uses ordinary Next.js and can run on a Node server or a compatible Next.js host. It does not depend on Sites authentication or Cloudflare D1. Add any new hosting domain to Firebase Authentication’s authorized domains before testing admin sign-in there.

The ZIP contains source and assets, not node_modules or a prebuilt server. Install dependencies before running it. No Git history, credentials or service-account private keys are included. Firebase web configuration is public app identification; Firestore rules enforce write access.
