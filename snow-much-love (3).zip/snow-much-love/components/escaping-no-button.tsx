"use client";

import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";

const WORDS = ["try to catch me 🙈", "are you sure? 🥺", "really?? 😭", "think again...", "can't catch me 😝", "too slow, Sandunika 😂"];
type Point = { x: number; y: number };

export function EscapingNoButton({ enabled, gentle, active, onAttempt, onDecline }: { enabled: boolean; gentle: boolean; active: boolean; onAttempt: () => void; onDecline: () => void }) {
  const button = useRef<HTMLButtonElement>(null);
  const anchor = useRef<HTMLSpanElement>(null);
  const cooldown = useRef(0);
  const count = useRef(0);
  const destination = useRef<Point | null>(null);
  const [position, setPosition] = useState<Point | null>(null);
  const [label, setLabel] = useState(WORDS[0]);

  const escape = useCallback((pointer: Point, force = false) => {
    if (!active || !enabled || !button.current || (!force && performance.now() - cooldown.current < 120)) return;
    cooldown.current = performance.now();
    const width = Math.min(220, window.innerWidth - 36);
    const height = Math.max(76, button.current.getBoundingClientRect().height);
    const safe = 18;
    const maxX = Math.max(safe, window.innerWidth - width - safe);
    const maxY = Math.max(safe, window.innerHeight - height - safe);
    const obstacles = [".yes-button", ".music-button"].flatMap(selector => {
      const rect = document.querySelector(selector)?.getBoundingClientRect();
      return rect ? [rect] : [];
    });
    const candidates: Point[] = [
      { x: safe, y: Math.min(maxY, safe + 65) }, { x: maxX, y: Math.min(maxY, safe + 65) },
      { x: safe, y: maxY }, { x: maxX, y: maxY },
      { x: (maxX + safe) / 2, y: maxY },
      ...Array.from({ length: 18 }, () => ({ x: safe + Math.random() * (maxX - safe), y: safe + Math.random() * (maxY - safe) }))
    ];
    const usable = candidates.filter(p => obstacles.every(rect => p.x + width + 20 < rect.left || p.x - 20 > rect.right || p.y + height + 20 < rect.top || p.y - 20 > rect.bottom));
    const choices = (usable.length ? usable : candidates).sort((a, b) => Math.hypot(b.x + width / 2 - pointer.x, b.y + height / 2 - pointer.y) - Math.hypot(a.x + width / 2 - pointer.x, a.y + height / 2 - pointer.y));
    const pick = choices[Math.floor(Math.random() * Math.min(3, choices.length))];
    destination.current = pick;
    setPosition(pick);
    count.current += 1;
    setLabel(WORDS[Math.min(count.current, WORDS.length - 1)]);
    onAttempt();
  }, [active, enabled, onAttempt]);

  useEffect(() => {
    if (!active || !enabled) { destination.current = null; setPosition(null); return; }
    const move = (e: MouseEvent | PointerEvent) => {
      if (("pointerType" in e && e.pointerType === "touch") || !button.current || !anchor.current) return;
      const question = document.getElementById("question")?.getBoundingClientRect();
      if (!question || question.bottom < 60 || question.top > window.innerHeight - 60) return;
      const rect = button.current.getBoundingClientRect();
      const dx = Math.max(rect.left - e.clientX, 0, e.clientX - rect.right);
      const dy = Math.max(rect.top - e.clientY, 0, e.clientY - rect.bottom);
      if (Math.hypot(dx, dy) < 110) escape({ x: e.clientX, y: e.clientY });
    };
    const resetOffscreen = () => {
      const question = document.getElementById("question")?.getBoundingClientRect();
      if (!question || question.bottom < 60 || question.top > window.innerHeight - 60) { destination.current = null; setPosition(null); }
    };
    const resize = () => { destination.current = null; setPosition(null); };
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("mousemove", move, { passive: true });
    window.addEventListener("scroll", resetOffscreen, { passive: true });
    window.addEventListener("resize", resize);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("mousemove", move); window.removeEventListener("scroll", resetOffscreen); window.removeEventListener("resize", resize); };
  }, [active, enabled, escape]);

  const control = <button ref={button} type="button" aria-label="No" data-escape-count={count.current} data-gentle={gentle} className={`no-button ${position ? "floating-no" : ""}`} style={position ? { "--no-x": `${position.x}px`, "--no-y": `${position.y}px` } as CSSProperties : undefined}
    onPointerEnter={e => { if (e.pointerType !== "touch") escape({ x: e.clientX, y: e.clientY }); }}
    onMouseEnter={e => escape({ x: e.clientX, y: e.clientY })}
    onMouseDown={e => { if (enabled) { e.preventDefault(); escape({ x: e.clientX, y: e.clientY }); } }}
    onPointerDown={e => { if (enabled) { e.preventDefault(); e.stopPropagation(); escape({ x: e.clientX, y: e.clientY }, true); } }}
    onClick={e => { if (e.detail === 0 || !enabled) onDecline(); else { e.preventDefault(); escape({ x: e.clientX, y: e.clientY }, true); } }}
  ><span className="no-button-title">NO <span aria-hidden="true">🙈</span></span><span className="no-button-caption" aria-hidden="true">{label}</span></button>;
  return <><span ref={anchor} className="no-anchor" />{active && (position ? createPortal(control, document.body) : control)}</>;
}
