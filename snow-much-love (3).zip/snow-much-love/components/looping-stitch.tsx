"use client";

import { useEffect, useRef, useState } from "react";

const POSTER = "/images/stitch-sandunika.jpg";
const ANIMATION = "/videos/stitch-loop-v3.webp";

/** Animated image remains visible if a browser blocks or cannot decode the MP4. */
export function LoopingStitch({ enabled, muted, label }: { enabled: boolean; muted: boolean; label: string }) {
  const wrapper = useRef<HTMLDivElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const el = video.current;
    const container = wrapper.current;
    if (!el || !container) return;
    let inView = true;
    let disposed = false;
    const sync = () => {
      if (disposed) return;
      const active = enabled && inView && !document.hidden;
      setVisible(active);
      if (active) void el.play().catch(() => { if (!disposed) setPlaying(false); });
      else { el.pause(); setPlaying(false); }
    };
    const observer = new IntersectionObserver(entries => { inView = entries[0].isIntersecting; sync(); }, { threshold: .01 });
    observer.observe(container);
    document.addEventListener("visibilitychange", sync);
    document.addEventListener("pointerdown", sync, { passive: true });
    document.addEventListener("touchstart", sync, { passive: true });
    sync();
    return () => {
      disposed = true; el.pause(); observer.disconnect();
      document.removeEventListener("visibilitychange", sync);
      document.removeEventListener("pointerdown", sync);
      document.removeEventListener("touchstart", sync);
    };
  }, [enabled, muted]);

  return <div ref={wrapper} className="stitch-loop" data-playback={enabled && visible ? (playing ? "video" : "image-fallback") : "paused"}>
    <img src={enabled && visible && !playing ? ANIMATION : POSTER} alt={label} width="360" height="640" />
    <video ref={video} src="/videos/stitch-play-v3.mp4" poster={POSTER} autoPlay={enabled} muted={muted} playsInline loop preload="auto" aria-hidden="true" tabIndex={-1}
      className={playing && enabled && visible ? "playing" : ""}
      onPlaying={() => setPlaying(true)} onPause={() => setPlaying(false)} onError={() => setPlaying(false)} onWaiting={() => setPlaying(false)} />
  </div>;
}
