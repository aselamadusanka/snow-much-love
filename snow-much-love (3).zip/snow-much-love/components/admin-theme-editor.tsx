"use client";
import { Check, Music2, Paintbrush } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { DEFAULT_SETTINGS, THEME_PRESETS, type SiteSettings } from "@/lib/site-settings";

export function AdminThemeEditor({ draft, onChange }: { draft: SiteSettings; onChange: (next: SiteSettings) => void }) {
  const select = (id: SiteSettings["themePreset"]) => {
    const custom = draft.themePreset === "custom" ? draft.theme : draft.customTheme || DEFAULT_SETTINGS.theme;
    const preset = THEME_PRESETS.find(theme => theme.id === id);
    onChange({ ...draft, themePreset: id, customTheme: { ...custom }, theme: { ...(preset?.colors || custom) } });
  };
  const setColor = (key: keyof SiteSettings["theme"], value: string) => {
    const theme = { ...draft.theme, [key]: value };
    onChange({ ...draft, theme, customTheme: { ...theme }, themePreset: "custom" });
  };
  return <>
    <div className="studio-section-heading"><div><h2>A mood for your story</h2><p>Three ready-made themes, or a palette that’s completely yours.</p></div></div>
    <div className="studio-theme-presets" role="group" aria-label="Theme presets">
      {THEME_PRESETS.map(preset => <button type="button" key={preset.id} className="studio-theme-choice" aria-pressed={draft.themePreset === preset.id} onClick={() => select(preset.id)}>
        <span className="theme-art" style={{ background: `linear-gradient(135deg,${preset.colors.background},${preset.colors.accent})` }}><span>{preset.emoji}</span><i style={{ background: preset.colors.primary }} /><i style={{ background: preset.colors.card }} /><i style={{ background: preset.colors.accent }} /></span>
        <span className="theme-name">{preset.name}{draft.themePreset === preset.id && <Check size={16} />}</span><small>{preset.description}</small>
      </button>)}
      <button type="button" className="studio-theme-choice" aria-pressed={draft.themePreset === "custom"} onClick={() => select("custom")}><span className="theme-art custom-art"><Paintbrush size={33} /><span className="custom-dots">● ● ●</span></span><span className="theme-name">Custom{draft.themePreset === "custom" && <Check size={16} />}</span><small>Your colors, saved just for you</small></button>
    </div>
    <div className="studio-colors">{(Object.keys(draft.theme) as Array<keyof SiteSettings["theme"]>).map(key => <div className="studio-color-field" key={key}><Label htmlFor={`theme-${key}`}>{({ primary: "Buttons & highlights", accent: "Hearts & accents", background: "Background", text: "Text", card: "Cards" })[key]}</Label><div><input id={`theme-${key}`} type="color" value={draft.theme[key]} onChange={e => setColor(key, e.target.value)} /><span>{draft.theme[key].toUpperCase()}</span></div></div>)}</div>
    <p className="studio-help">Changing a color switches to your custom theme. Your custom palette is kept when you try another preset.</p>
    <div className="studio-motion"><h2><Music2 size={22} /> Music & motion</h2><div className="studio-field"><Label htmlFor="music-level">Calm music volume <span>{Math.round(draft.musicVolume * 100)}%</span></Label><Slider id="music-level" aria-label="Calm music volume" min={0} max={0.7} step={0.01} value={[draft.musicVolume]} onValueChange={([value]) => onChange({ ...draft, musicVolume: value })} /><p>Music begins after the visitor’s first tap. They can mute it any time.</p></div><div className="studio-field"><Label htmlFor="video-speed">Background playback speed <span>{draft.videoSpeed.toFixed(2)}×</span></Label><Slider id="video-speed" aria-label="Background playback speed" min={0.08} max={0.5} step={0.01} value={[draft.videoSpeed]} onValueChange={([value]) => onChange({ ...draft, videoSpeed: value })} /><p>A gentle loop while still; synchronized movement while scrolling.</p></div></div>
  </>;
}
