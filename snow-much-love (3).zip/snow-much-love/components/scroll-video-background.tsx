"use client";

import { useEffect, useRef } from "react";

const FRAME_COUNT = 145;
const CROSSFADE = 8;
const CYCLE = FRAME_COUNT - CROSSFADE;
const SCENES = [
  { id: "hello", start: 0, end: .12 }, { id: "cinema", start: .12, end: .48 },
  { id: "question", start: .48, end: .54 }, { id: "celebration", start: .54, end: .60 },
  { id: "date", start: .60, end: .70 }, { id: "food", start: .70, end: .78 },
  { id: "vibe", start: .78, end: .85 }, { id: "intermission", start: .85, end: .94 },
  { id: "agreement", start: .94, end: 1 }, { id: "confirmed", start: 1, end: 1.12 },
];

/** Continuous slow playback, with scroll distance added to the same video timeline. */
export function ScrollVideoBackground({ enabled, gentle, revision, speed = .18 }: { enabled: boolean; gentle: boolean; revision: number; speed?: number }) {
  const scene = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const refresh = useRef<() => void>(() => {});
  const playback = useRef(speed);
  playback.current = speed;
  useEffect(() => {
    const surface = canvas.current;
    const context = surface?.getContext("2d", { alpha: false });
    if (!surface || !context) return;
    const cache = new Map<number, HTMLImageElement>();
    const loading = new Map<number, { image: HTMLImageElement; timeout: ReturnType<typeof setTimeout> }>();
    const failed = new Map<number, number>();
    let target = CROSSFADE, desired = 0, playhead = 0, progress = 0;
    let last = 0, lastScroll = 0, frame = 0, destroyed = false, dirty = true;
    const distance = (index: number) => Math.min(Math.abs(index - target), FRAME_COUNT - Math.abs(index - target));
    const loadNearby = (wanted: number[]) => {
      if (destroyed || document.hidden) return;
      for (const index of wanted) {
        if (loading.size >= 4) break;
        if (index < 0 || index >= FRAME_COUNT || cache.has(index) || loading.has(index) || (failed.get(index) || 0) > Date.now()) continue;
        const image = new Image();
        const complete = (success: boolean) => {
          const entry = loading.get(index); if (!entry) return;
          clearTimeout(entry.timeout); loading.delete(index); image.onload = null; image.onerror = null;
          if (destroyed) return;
          if (success) {
            cache.set(index, image);
            [...cache.keys()].sort((a, b) => distance(a) - distance(b)).slice(30).forEach(key => cache.delete(key));
          } else failed.set(index, Date.now() + 15000);
        };
        loading.set(index, { image, timeout: setTimeout(() => complete(false), 10000) });
        image.onload = () => complete(true); image.onerror = () => complete(false);
        image.src = `/frames/stitch-v3/frame-${String(index).padStart(3, "0")}.webp`;
      }
    };
    const drawImage = (image: HTMLImageElement, alpha: number, width: number, height: number) => {
      const scale = Math.max(width / image.naturalWidth, height / image.naturalHeight);
      const w = image.naturalWidth * scale, h = image.naturalHeight * scale;
      context.globalAlpha = alpha;
      context.drawImage(image, (width - w) / 2, (height - h) * .43, w, h);
    };
    const measure = () => {
      let nextProgress = 0;
      for (const chapter of SCENES) {
        const section = document.getElementById(chapter.id); if (!section) continue;
        const rect = section.getBoundingClientRect(); if (rect.top > 1) break;
        nextProgress = chapter.start + (chapter.end - chapter.start) * Math.min(1, Math.max(0, -rect.top / Math.max(1, rect.height)));
      }
      desired += (nextProgress - progress) * CYCLE;
      progress = nextProgress;
      scene.current?.style.setProperty("--background-scale", String(gentle ? 1 : 1.015 + Math.min(progress, 1) * .055));
      const cinema = document.getElementById("cinema")?.getBoundingClientRect();
      scene.current?.classList.toggle("cinema-clear", !!cinema && cinema.top < window.innerHeight * .3 && cinema.bottom > window.innerHeight * .7);
      dirty = false;
    };
    const update = (now: number) => {
      if (destroyed || document.hidden || !enabled) { frame = 0; return; }
      const delta = last ? Math.min(64, now - last) : 16; last = now;
      if (dirty) measure();
      desired += delta / 1000 * 24 * playback.current;
      playhead += (desired - playhead) * (1 - Math.exp(-delta / 100));
      const position = ((playhead % CYCLE) + CYCLE) % CYCLE + CROSSFADE;
      target = Math.floor(position);
      const wrapped = Math.max(0, target - CYCLE);
      loadNearby([target, Math.min(144, target + 1), ...(target >= CYCLE ? [wrapped, wrapped + 1] : []), target + 2, target - 1, target + 3, target - 2, target + 4]);
      const nearest = cache.get(target) || cache.get([...cache.keys()].sort((a, b) => distance(a) - distance(b))[0]);
      if (nearest) {
        const width = window.innerWidth, height = window.innerHeight;
        const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
        if (surface.width !== Math.round(width * ratio) || surface.height !== Math.round(height * ratio)) { surface.width = Math.round(width * ratio); surface.height = Math.round(height * ratio); }
        context.setTransform(ratio, 0, 0, ratio, 0, 0);
        drawImage(nearest, 1, width, height);
        const nextImage = cache.get(target + 1);
        if (cache.has(target) && nextImage) drawImage(nextImage, position - target, width, height);
        if (position >= CYCLE) {
          const beginning = cache.get(wrapped);
          if (beginning) drawImage(beginning, Math.min(1, (position - CYCLE) / CROSSFADE), width, height);
        }
        context.globalAlpha = 1; surface.dataset.ready = "true"; surface.dataset.frame = String(target);
      }
      surface.dataset.progress = progress.toFixed(4);
      surface.dataset.playhead = playhead.toFixed(3);
      surface.dataset.playback = now - lastScroll < 180 ? "scrolling" : "drifting";
      frame = requestAnimationFrame(update);
    };
    const queue = () => { dirty = true; if (!frame && !destroyed && !document.hidden) { last = 0; frame = requestAnimationFrame(update); } };
    const scroll = () => { lastScroll = performance.now(); queue(); };
    const visible = () => { if (document.hidden) { cancelAnimationFrame(frame); frame = 0; last = 0; } else queue(); };
    refresh.current = queue;
    window.addEventListener("scroll", scroll, { passive: true }); window.addEventListener("resize", queue); document.addEventListener("visibilitychange", visible);
    queue();
    return () => {
      destroyed = true; cancelAnimationFrame(frame);
      loading.forEach(({ image, timeout }) => { clearTimeout(timeout); image.onload = null; image.onerror = null; });
      loading.clear(); cache.clear(); refresh.current = () => {};
      window.removeEventListener("scroll", scroll); window.removeEventListener("resize", queue); document.removeEventListener("visibilitychange", visible);
    };
  }, [enabled, gentle]);
  useEffect(() => { refresh.current(); }, [revision]);
  return <div className="scroll-backdrop" ref={scene} aria-hidden="true"><canvas ref={canvas} className="scroll-film" /><div className="background-wash" /></div>;
}
