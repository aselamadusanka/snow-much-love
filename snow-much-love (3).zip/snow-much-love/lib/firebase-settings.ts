"use client";

import { doc, getDocFromServer, onSnapshot, runTransaction } from "firebase/firestore";
import { firebaseDatabase } from "./firebase-client";
import { FIREBASE_SETTINGS_PATH } from "./firebase-config";
import { settingsSchema, snapshotSchema, type SettingsSnapshot, type SiteSettings } from "./site-settings";

export class SettingsConflict extends Error {
  status = 409;
  constructor() { super("Settings changed in another session. Reload the saved settings before saving."); }
}

export function subscribeFirebaseSettings(onChange: (snapshot: SettingsSnapshot | null) => void, onError: (error: unknown) => void) {
  return onSnapshot(doc(firebaseDatabase(), FIREBASE_SETTINGS_PATH), { includeMetadataChanges: true }, snapshot => {
    // A cache-only missing document does not prove that the cloud is empty.
    if (snapshot.metadata.fromCache && !snapshot.exists()) return;
    try { onChange(snapshot.exists() ? snapshotSchema.parse(snapshot.data()) : null); }
    catch (error) { onError(error); }
  }, onError);
}

export async function readFirebaseSettings(): Promise<SettingsSnapshot | null> {
  const result = await getDocFromServer(doc(firebaseDatabase(), FIREBASE_SETTINGS_PATH));
  return result.exists() ? snapshotSchema.parse(result.data()) : null;
}

export async function saveFirebaseSettings(settings: SiteSettings, expectedRevision: string): Promise<SettingsSnapshot> {
  const parsed = settingsSchema.parse(settings);
  const reference = doc(firebaseDatabase(), FIREBASE_SETTINGS_PATH);
  return runTransaction(firebaseDatabase(), async transaction => {
    const current = await transaction.get(reference);
    const revision = current.exists() ? snapshotSchema.parse(current.data()).revision : "default";
    if (revision !== expectedRevision) throw new SettingsConflict();
    const next = { settings: parsed, revision: crypto.randomUUID() };
    // JSON serialization removes optional undefined properties rejected by Firestore.
    transaction.set(reference, JSON.parse(JSON.stringify(next)));
    return next;
  });
}

export function firebaseErrorMessage(reason: unknown): string {
  const code = (reason as { code?: string })?.code;
  if (code === "auth/popup-closed-by-user" || code === "auth/cancelled-popup-request") return "Sign-in was cancelled. Your changes are still here.";
  if (code === "auth/popup-blocked") return "Allow the Google sign-in popup, then try again.";
  if (code === "auth/unauthorized-domain") return "Add this website’s domain to Firebase Authentication → Settings → Authorized domains.";
  if (code === "auth/operation-not-allowed" || code === "auth/configuration-not-found") return "Enable the Google sign-in provider in Firebase Authentication, then try again.";
  if (code === "permission-denied") return "Firebase denied access. Check the Firestore rules and use the invitation owner’s Google account.";
  if (code === "unavailable" || code === "auth/network-request-failed") return "Firebase could not connect. Check your connection and Firebase setup, then retry.";
  return reason instanceof Error ? reason.message : "Firebase could not connect. Please try again.";
}
