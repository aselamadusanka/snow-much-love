// Firebase web configuration identifies this app. Authorization is enforced by
// Firebase Authentication and firestore.rules, never by hiding this web key.
export const firebaseConfig = {
  apiKey: "AIzaSyBEDZk5qGdnw52sTvwado0jZlaOeJLytdw",
  authDomain: "snow-much-love.firebaseapp.com",
  projectId: "snow-much-love",
  storageBucket: "snow-much-love.firebasestorage.app",
  messagingSenderId: "84451267503",
  appId: "1:84451267503:web:de61df42363f568370955a",
  measurementId: "G-KH76JJJ4CB",
};
export const FIREBASE_SETTINGS_PATH = "siteSettings/public";
