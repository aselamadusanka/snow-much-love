import { z } from "zod";
import type { CSSProperties } from "react";

export const CHOICE_COLORS = ["peach", "pink", "yellow", "lavender", "green", "blue"] as const;
const choice = z.object({
  id: z.string().regex(/^[a-zA-Z0-9_-]{1,50}$/),
  name: z.string().trim().min(1, "Add a name.").max(40),
  emoji: z.string().trim().min(1, "Add an emoji or icon.").max(24),
  color: z.enum(CHOICE_COLORS),
}).strict();
const choices = z.array(choice).min(1).max(16).refine(items => new Set(items.map(item => item.id)).size === items.length, "Each option needs a unique ID.");
const color = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Use a six-digit hex color.");
const themeSchema = z.object({ primary: color, accent: color, background: color, text: color, card: color }).strict();
export const THEME_PRESETS = [
  { id: "snow", name: "Snow Blue", emoji: "❄️", description: "Our original snowy little world", colors: { primary: "#438ed5", accent: "#ed98b8", background: "#edf7ff", text: "#163a5f", card: "#ffffff" } },
  { id: "rose", name: "Rose Pink", emoji: "🌷", description: "Warm blush, a little romance", colors: { primary: "#bc3f72", accent: "#d99974", background: "#fff0f5", text: "#59233d", card: "#fffafb" } },
  { id: "lavender", name: "Lavender", emoji: "🔮", description: "Soft purple, a dreamy evening", colors: { primary: "#7855ba", accent: "#dca0c8", background: "#f1edff", text: "#372456", card: "#fdfbff" } },
] as const;
export const settingsSchema = z.object({
  foods: choices,
  locations: choices,
  theme: themeSchema,
  themePreset: z.enum(["snow", "rose", "lavender", "custom"]).default("custom"),
  customTheme: themeSchema.optional(),
  reservationAmount: z.number().int("Use a whole rupee amount.").min(0).max(1000000).default(10000),
  musicVolume: z.number().min(0).max(0.7),
  videoSpeed: z.number().min(0.08).max(0.5),
}).strict();
export type SiteSettings = z.infer<typeof settingsSchema>;
export type Choice = z.infer<typeof choice>;
export type SettingsSnapshot = { settings: SiteSettings; revision: string };
export const snapshotSchema = z.object({ settings: settingsSchema, revision: z.string().min(1).max(80) });

export const DEFAULT_SETTINGS: SiteSettings = {
  foods: [
    { id: "pizza", name: "Pizza", emoji: "🍕", color: "peach" },
    { id: "sushi", name: "Sushi", emoji: "🍣", color: "pink" },
    { id: "burgers", name: "Burgers", emoji: "🍔", color: "yellow" },
    { id: "pasta", name: "Pasta", emoji: "🍝", color: "lavender" },
    { id: "tacos", name: "Tacos", emoji: "🌮", color: "green" },
    { id: "ramen", name: "Ramen", emoji: "🍜", color: "blue" },
    { id: "dessert", name: "Dessert", emoji: "🍰", color: "pink" },
    { id: "coffee", name: "Coffee", emoji: "☕", color: "peach" },
  ],
  locations: [
    { id: "beach", name: "By the beach", emoji: "🏖️", color: "blue" },
    { id: "cafe", name: "A cozy café", emoji: "☕", color: "peach" },
    { id: "cinema", name: "The cinema", emoji: "🎬", color: "lavender" },
    { id: "restaurant", name: "A lovely restaurant", emoji: "🍽️", color: "pink" },
  ],
  theme: { primary: "#438ed5", accent: "#ed98b8", background: "#edf7ff", text: "#163a5f", card: "#ffffff" },
  themePreset: "snow",
  customTheme: { primary: "#438ed5", accent: "#ed98b8", background: "#edf7ff", text: "#163a5f", card: "#ffffff" },
  reservationAmount: 10000,
  musicVolume: 0.24,
  videoSpeed: 0.18,
};

export const formatAmount = (amount: number): string => new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(amount);

export function themeVariables(theme: SiteSettings["theme"]): CSSProperties {
  const rgb = theme.primary.slice(1).match(/.{2}/g)!.map(v => parseInt(v, 16) / 255);
  const luminance = rgb.reduce((sum, c, i) => sum + (c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)) * [0.2126, 0.7152, 0.0722][i], 0);
  return {
    "--primary": theme.primary, "--blue": theme.primary, "--pink": theme.accent,
    "--theme-accent": theme.accent, "--background": theme.background,
    "--ink": theme.text, "--foreground": theme.text, "--card": theme.card,
    "--card-foreground": theme.text, "--primary-foreground": luminance > 0.35 ? "#102332" : "#ffffff",
    "--ring": theme.primary, "--border": `color-mix(in srgb, ${theme.primary} 22%, ${theme.card})`,
    "--muted-foreground": `color-mix(in srgb, ${theme.text} 72%, ${theme.card})`,
  } as CSSProperties;
}

export function formatTime(value: string): string {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) return "";
  const [hours, minutes] = value.split(":").map(Number);
  return `${hours % 12 || 12}:${String(minutes).padStart(2, "0")} ${hours >= 12 ? "PM" : "AM"}`;
}

export function isFutureDateTime(date: Date, time: string, now = new Date()): boolean {
  if (!formatTime(time)) return false;
  const [hours, minutes] = time.split(":").map(Number);
  const chosen = new Date(date);
  chosen.setHours(hours, minutes, 0, 0);
  return chosen.getTime() > now.getTime();
}
